from django.apps import AppConfig


class ClosetclientConfig(AppConfig):
    name = 'closetclient'
